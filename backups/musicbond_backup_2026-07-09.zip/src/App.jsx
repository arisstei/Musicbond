import { useState, useEffect } from 'react'
import { supabase } from './lib/supabaseClient'
import { LoginScreen } from './components/auth/LoginScreen'
import { OnboardingWizard } from './components/onboarding/OnboardingWizard'
// Αν έχεις Dashboard component, βεβαιώσου ότι η διαδρομή είναι σωστή, αλλιώς σχολίασέ το
import { Dashboard } from './components/dashboard/Dashboard' 
// import { MapSection } from './components/landing/MapSection' // Αν το χρησιμοποιείς

function App() {
  const [session, setSession] = useState(null)
  const [hasProfile, setHasProfile] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // 1. Έλεγχος αν υπάρχει ενεργό session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      if (session) {
        checkProfile(session.user.id)
      } else {
        setLoading(false)
      }
    })

    // 2. Ακρόαση για αλλαγές (Login/Logout)
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
      if (session) {
        setLoading(true) // Ξαναρχίζει το loading μέχρι να βρούμε προφίλ
        checkProfile(session.user.id)
      } else {
        setHasProfile(false)
        setLoading(false)
      }
    })

    return () => subscription.unsubscribe()
  }, [])

  // Η συνάρτηση που ψάχνει το προφίλ και ΞΕΚΟΛΛΑΕΙ την εφαρμογή
  const checkProfile = async (userId) => {
    try {
      console.log("Checking profile for user:", userId)
      
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single() // Περιμένουμε μία εγγραφή

      if (error && error.code !== 'PGRST116') {
        // Αν είναι πραγματικό λάθος (όχι απλά "δεν βρέθηκε")
        console.error('Error fetching profile:', error)
      }

      if (data) {
        console.log("Profile found!")
        setHasProfile(true)
      } else {
        console.log("No profile found. Redirecting to Wizard.")
        setHasProfile(false)
      }

    } catch (error) {
      console.error("Unexpected error:", error)
      setHasProfile(false)
    } finally {
      // ΣΗΜΑΝΤΙΚΟ: Σταματάμε το loading ό,τι κι αν γίνει!
      setLoading(false)
    }
  }

  // --- RENDERING ---

  // 1. Loading Screen (Comic Style)
  if (loading) {
    return (
      <div style={{ 
        height: '100vh', 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        background: '#fff7dd',
        fontFamily: 'Comic Sans MS, cursive',
        fontSize: '1.5em',
        fontWeight: 'bold',
        color: '#333'
      }}>
        Loading your vibe... 🎵
      </div>
    )
  }

  // 2. Αν δεν έχεις κάνει Login -> Δείξε LoginScreen
  if (!session) {
    return <LoginScreen />
  }

  // 3. Αν είσαι Logged in αλλά ΔΕΝ έχεις προφίλ -> Δείξε Wizard
  if (!hasProfile) {
    return <OnboardingWizard />
  }

  // 4. Αν έχεις τα πάντα -> Δείξε το Dashboard (Κεντρική Σελίδα)
  return (
    <div className="App">
       {/* Εδώ βάζεις το Dashboard ή ό,τι είχαμε στην αρχική */}
       <Dashboard session={session} /> 
    </div>
  )
}

export default App