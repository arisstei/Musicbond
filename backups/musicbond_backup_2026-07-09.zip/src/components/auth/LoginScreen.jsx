import { useState } from 'react'
// ΑΛΛΑΓΗ ΕΔΩ: Σωστή διαδρομή για το src/lib
import { supabase } from '../../lib/supabaseClient'; // ΣΩΣΤΟ (με διπλό ../../) 
import { ComicCard } from '../common/ComicCard'
import { ComicButton } from '../common/ComicButton'

export function LoginScreen() {
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const [isSignUp, setIsSignUp] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [info, setInfo] = useState(null)

  const handleAuth = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setInfo(null)

    console.log("Attempting auth with:", identifier)

    try {
      if (isSignUp) {
        // --- LOGIC ΓΙΑ ΕΓΓΡΑΦΗ (SIGN UP) ---
        const { data, error } = await supabase.auth.signUp({
          email: identifier,
          password: password,
        })

        if (error) throw error

        // Επιτυχία Εγγραφής
        console.log("Signup success:", data)
        alert("Registration Successful! Check your email to confirm your account.")
        setInfo("Check your email for the confirmation link!")
        setIsSignUp(false) // Γυρνάμε σε login mode

      } else {
        // --- LOGIC ΓΙΑ ΕΙΣΟΔΟ (LOGIN) ---
        const { data, error } = await supabase.auth.signInWithPassword({
          email: identifier,
          password: password,
        })

        if (error) throw error

        console.log("Login success:", data)
        // Το App.jsx θα καταλάβει αυτόματα ότι συνδέθηκες
      }
    } catch (error) {
      console.error("Auth Error:", error.message)
      setError(error.message)
      alert("Error: " + error.message) 
    } finally {
      setLoading(false)
    }
  }

  // --- STYLES ---
  const page = {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '40px 16px',
    background: '#fff7dd',
    backgroundImage: 'radial-gradient(#ffe9a9 1px, transparent 1px)',
    backgroundSize: '16px 16px',
    fontFamily: 'Comic Sans MS, Comic Sans, cursive, sans-serif',
  }

  const title = {
    fontWeight: 900,
    fontSize: '2.4em',
    letterSpacing: 2,
    color: '#ffb300',
    textTransform: 'uppercase',
    textShadow: '-4px 4px 0 #111',
    marginBottom: 6,
  }

  const subtitle = {
    fontWeight: 'bold',
    fontSize: '0.98em',
    color: '#333',
    marginBottom: 18,
  }

  const label = {
    fontWeight: 'bold',
    fontSize: '0.95em',
    color: '#222',
    marginBottom: 4,
  }

  const input = {
    width: '100%',
    padding: '10px',
    border: '3px solid #111',
    borderRadius: 8,
    fontSize: '1em',
    marginBottom: 12,
    backgroundColor: '#f9f7f0',
    boxShadow: '2px 2px 0 #fbd700',
    outline: 'none',
  }

  const sectionDivider = {
    margin: '18px 0 12px',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: '0.85em',
    color: '#444',
  }

  const errorStyle = {
    marginTop: 10,
    padding: '8px 10px',
    borderRadius: 10,
    border: '3px solid #b70909',
    background: '#ffe3e3',
    color: '#b70909',
    fontWeight: 'bold',
    fontSize: '0.85em',
    boxShadow: '3px 3px 0 #fbc1c1',
  }

  const infoStyle = {
    marginTop: 10,
    padding: '8px 10px',
    borderRadius: 10,
    border: '3px solid #1e7d0c',
    background: '#e7ffd9',
    color: '#1e7d0c',
    fontWeight: 'bold',
    fontSize: '0.85em',
    boxShadow: '3px 3px 0 #abf59f',
  }

  const toggleText = {
    marginTop: 14,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: '0.85em',
    color: '#333',
  }

  const toggleLink = {
    color: '#ff1744',
    cursor: 'pointer',
    textDecoration: 'underline',
    marginLeft: 4,
  }

  return (
    <div style={page}>
      <ComicCard style={{ maxWidth: 420, width: '100%' }}>
        <h1 style={title}>Musicbond</h1>
        <p style={subtitle}>
          {isSignUp
            ? 'Register to join the comic musicverse.'
            : 'Sign in to enter the comic musicverse.'}
        </p>
        
        <form onSubmit={handleAuth} autoComplete="off">
          <label htmlFor="identifier" style={label}>Email</label>
          <input
            id="identifier"
            type="email"
            style={input}
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder="you@example.com"
            required
          />

          <label htmlFor="password" style={label}>Password</label>
          <input
            id="password"
            type="password"
            style={input}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            required
            minLength={6} 
          />

          <ComicButton
            type="submit"
            variant="yellow"
            disabled={loading}
            style={{ width: '100%', marginTop: 4 }}
          >
            {loading
              ? isSignUp ? 'Creating account...' : 'Signing in...'
              : isSignUp ? 'Sign up' : 'Sign in'}
          </ComicButton>
        </form>

        {error && (
          <div style={errorStyle}>{error}</div>
        )}
        {info && !error && (
          <div style={infoStyle}>{info}</div>
        )}

        <div style={toggleText}>
          {isSignUp ? 'Already have an account?' : "Don't have an account?"}
          <span
            style={toggleLink}
            onClick={() => {
              setIsSignUp((prev) => !prev)
              setError(null)
              setInfo(null)
            }}
          >
            {isSignUp ? 'Log In' : 'Sign Up'}
          </span>
        </div>
      </ComicCard>
    </div>
  )
}