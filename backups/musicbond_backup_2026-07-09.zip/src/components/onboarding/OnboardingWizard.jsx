import { useState } from 'react'
// ΠΡΟΣΟΧΗ: Εδώ έβαλα το ../../ για να το βρίσκει σωστά!
import { supabase } from '../../lib/supabaseClient' 
import { ComicCard } from '../common/ComicCard'
import { ComicButton } from '../common/ComicButton'

export function OnboardingWizard() {
  const [genre, setGenre] = useState('Rock')
  const [mood, setMood] = useState('Energetic')
  const [instrument, setInstrument] = useState('Guitar')
  const [loading, setLoading] = useState(false)

  // Συνάρτηση που διαλέγει το αρχικό χρώμα (Music DNA Color)
  const determineColor = (g, m) => {
    if (g === 'Rock') return '#ff2a2a' // Red
    if (g === 'Jazz') return '#4a90e2' // Blue
    if (g === 'Electronic') return '#b8e986' // Neon Green
    if (g === 'Classical') return '#f8e71c' // Gold
    if (m === 'Sad') return '#50e3c2' // Teal
    return '#bd10e0' // Purple default
  }

  const saveVibe = async () => {
    setLoading(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      
      if (!user) throw new Error("No user found. Please log in again.")

      const initialColor = determineColor(genre, mood)
      
      const preferences = {
        genre,
        mood,
        instrument,
        joined_at: new Date().toISOString()
      }

      console.log("Saving vibe for user:", user.id)

      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          username: user.email?.split('@')[0],
          current_color: initialColor,
          preferences: preferences
        })

      if (error) throw error

      alert("Vibe Locked In! Welcome to Musicbond.")
      window.location.reload()

    } catch (error) {
      console.error('Error saving vibe:', error)
      alert('Error saving vibe: ' + error.message)
    } finally {
      setLoading(false)
    }
  }

  // --- STYLES ---
  const container = {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: '#fff7dd',
    backgroundImage: 'radial-gradient(#ffe9a9 1px, transparent 1px)',
    backgroundSize: '16px 16px',
    padding: 20
  }

  const title = {
    fontSize: '2em',
    fontWeight: 900,
    marginBottom: 10,
    color: '#ffb300',
    textShadow: '-3px 3px 0 #111',
    textTransform: 'uppercase',
    letterSpacing: 1
  }

  const label = {
    display: 'block',
    fontWeight: 'bold',
    marginBottom: 5,
    fontSize: '0.9em',
    color: '#222'
  }

  const select = {
    width: '100%',
    padding: '10px',
    border: '3px solid #111',
    borderRadius: 8,
    fontSize: '1em',
    marginBottom: 15,
    backgroundColor: '#fff',
    boxShadow: '3px 3px 0 #eee',
    outline: 'none',
    cursor: 'pointer'
  }

  return (
    <div style={container}>
      <ComicCard style={{ maxWidth: 500, width: '100%' }}>
        <h1 style={title}>Tune Your Vibe</h1>
        <p style={{ marginBottom: 20, fontWeight: 600 }}>
          Answer 3 quick questions to generate your initial Music Color.
        </p>

        <label style={label}>Favorite Genre</label>
        <select style={select} value={genre} onChange={(e) => setGenre(e.target.value)}>
          <option value="Rock">Rock</option>
          <option value="Jazz">Jazz</option>
          <option value="Electronic">Electronic</option>
          <option value="Classical">Classical</option>
          <option value="Pop">Pop</option>
          <option value="Folk">Folk</option>
        </select>

        <label style={label}>Mood</label>
        <select style={select} value={mood} onChange={(e) => setMood(e.target.value)}>
          <option value="Energetic">Energetic</option>
          <option value="Chill">Chill</option>
          <option value="Melancholic">Melancholic</option>
          <option value="Focus">Focus</option>
        </select>

        <label style={label}>Instrument</label>
        <select style={select} value={instrument} onChange={(e) => setInstrument(e.target.value)}>
          <option value="Guitar">Guitar</option>
          <option value="Piano">Piano</option>
          <option value="Drums">Drums</option>
          <option value="Synthesizer">Synthesizer</option>
          <option value="Vocals">Vocals</option>
        </select>

        <ComicButton 
          variant="yellow" 
          onClick={saveVibe} 
          disabled={loading}
          style={{ width: '100%', marginTop: 10 }}
        >
          {loading ? 'Saving...' : 'Save my vibe'}
        </ComicButton>

      </ComicCard>
    </div>
  )
}