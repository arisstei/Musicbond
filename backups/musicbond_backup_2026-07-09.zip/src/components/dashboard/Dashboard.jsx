import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'
import { Hero } from '../landing/Hero'
import { FeaturesGrid } from '../landing/FeaturesGrid'
import { MapSection } from '../landing/MapSection'
import { ComicCard } from '../common/ComicCard'

export function Dashboard({ session }) {
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getProfile()
  }, [session])

  const getProfile = async () => {
    try {
      setLoading(true)
      const { user } = session

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single()

      if (data) setProfile(data)
    } catch (error) {
      console.error('Error loading user data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div style={{ 
        height: '100vh', 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        fontFamily: 'Comic Sans MS', 
        background: '#fff7dd' 
      }}>
        Loading your HQ...
      </div>
    )
  }

  return (
    <div style={{ backgroundColor: '#fff7dd', minHeight: '100vh', width: '100%', overflowX: 'hidden' }}>
      
      <div style={{ position: 'relative' }}>
        <Hero 
          customTitle={profile?.username ? `Welcome, ${profile.username}!` : 'Musicbond HQ'} 
        />
        
        <button 
          onClick={() => supabase.auth.signOut()}
          style={{
            position: 'absolute', 
            top: 20, 
            right: 20,
            background: '#ff4444', 
            color: 'white', 
            border: '3px solid black',
            padding: '8px 16px', 
            fontWeight: 'bold', 
            cursor: 'pointer',
            fontFamily: 'Comic Sans MS', 
            boxShadow: '3px 3px 0 black',
            zIndex: 100
          }}
        >
          LOG OUT
        </button>
      </div>

      <div style={{ 
        padding: '20px', 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'stretch',
        flexWrap: 'wrap', 
        gap: '20px',
        backgroundColor: profile?.current_color || '#fff',
        borderBottom: '4px solid black'
      }}>
        
        <ComicCard style={{ flex: '1 1 250px', maxWidth: '400px', transform: 'rotate(-1deg)' }}>
          <h3 style={{ margin: '0 0 10px 0', fontSize: '1.1rem', borderBottom: '2px solid #eee' }}>MY SONIC DNA</h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: 15 }}>
            <div style={{ 
              width: 40, 
              height: 40, 
              backgroundColor: profile?.current_color, 
              border: '3px solid black', 
              borderRadius: '50%',
              boxShadow: '2px 2px 0 rgba(0,0,0,0.2)'
            }} />
            <div>
              <div style={{ fontWeight: '900', fontSize: '1.1rem' }}>{profile?.preferences?.genre || 'Unknown'}</div>
              <div style={{ fontSize: '0.9rem', color: '#666' }}>{profile?.preferences?.mood} Vibes</div>
            </div>
          </div>
        </ComicCard>
        
        <ComicCard style={{ flex: '1 1 250px', maxWidth: '400px', transform: 'rotate(1deg)' }}>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '1.1rem', borderBottom: '2px solid #eee' }}>CURRENT LOCATION</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: '1.5rem' }}>📍</span>
                <span style={{ fontWeight: '900', fontSize: '1.2rem' }}>
                    {profile?.current_district || 'Roaming Free'}
                </span>
            </div>
        </ComicCard>
      </div>

      <div style={{ padding: '40px 20px' }}>
        <h2 style={{ textAlign: 'center', fontFamily: 'Comic Sans MS', fontSize: '2rem', marginBottom: '30px', textShadow: '2px 2px 0 #fff' }}>
            YOUR TOOLS
        </h2>
        <FeaturesGrid />
      </div>

      <div id="map-section" style={{ borderTop: '4px solid black' }}>
        <MapSection />
      </div>

    </div>
  )
}