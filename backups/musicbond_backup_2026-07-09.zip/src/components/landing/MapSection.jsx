import { useState } from 'react'
import { ComicCard } from '../common/ComicCard'
import { ComicModal } from '../common/ComicModal'
import { ComicButton } from '../common/ComicButton'

export function MapSection() {
  const [bassModalOpen, setBassModalOpen] = useState(false)

  const sectionStyle = {
    maxWidth: 980,
    margin: '0 auto 56px',
  }

  const titleStyle = {
    fontWeight: 900,
    fontSize: '1.8em',
    letterSpacing: 1.5,
    textTransform: 'uppercase',
    color: '#ffb300',
    textShadow: '-3px 3px 0 #111',
    marginBottom: 16,
  }

  const subtitleStyle = {
    fontWeight: 'bold',
    fontSize: '0.95em',
    color: '#333',
    marginBottom: 18,
  }

  const mapWrapper = {
    position: 'relative',
    height: 360,
    borderRadius: 20,
    overflow: 'hidden',
  }

  const mapBackground = {
    position: 'absolute',
    inset: 0,
    backgroundImage: "url('/heraklion-city.gif')",
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    filter: 'saturate(1.1)',
  }

  const markerWrapper = {
    position: 'absolute',
    left: '52%',
    top: '46%',
    transform: 'translate(-50%, -50%)',
    display: 'flex',
    alignItems: 'center',
    gap: 10,
  }

  const markerDot = {
    width: 26,
    height: 26,
    borderRadius: '50%',
    background: '#ff1744',
    border: '4px solid #111',
    boxShadow: '3px 3px 0 #111',
    cursor: 'pointer',
  }

  const bubble = {
    padding: '10px 14px',
    background: '#fff',
    border: '4px solid #111',
    borderRadius: 16,
    boxShadow: '4px 4px 0 #111',
    fontWeight: 'bold',
    fontSize: '0.9em',
    color: '#111',
    whiteSpace: 'nowrap',
    transform: 'translateY(-40%)',
  }

  const bubbleTail = {
    position: 'absolute',
    left: 6,
    top: '50%',
    width: 14,
    height: 14,
    background: '#fff',
    borderLeft: '4px solid #111',
    borderBottom: '4px solid #111',
    transform: 'translateY(-10%) rotate(45deg)',
  }

  const markerContainer = {
    position: 'relative',
    display: 'flex',
    alignItems: 'center',
    gap: 10,
  }

  const bassMarkerWrapper = {
    position: 'absolute',
    left: '76%',
    top: '62%',
    transform: 'translate(-50%, -50%)',
  }

  const bassMarkerDot = {
    width: 26,
    height: 26,
    borderRadius: '50%',
    background: '#00e5ff',
    border: '4px solid #111',
    boxShadow: '3px 3px 0 #111',
    cursor: 'pointer',
  }

  const bassLabel = {
    marginTop: 6,
    padding: '4px 8px',
    background: '#fff',
    border: '3px solid #111',
    borderRadius: 12,
    boxShadow: '3px 3px 0 #111',
    fontWeight: 'bold',
    fontSize: '0.8em',
    whiteSpace: 'nowrap',
  }

  const modalText = {
    fontWeight: 'bold',
    fontSize: '0.98em',
    color: '#222',
    marginBottom: 18,
  }

  const modalActions = {
    display: 'flex',
    justifyContent: 'flex-end',
  }

  return (
    <section id="map-section" style={sectionStyle}>
      <ComicCard>
        <h2 style={titleStyle}>Explore Districts</h2>
        <p style={subtitleStyle}>
          Μια πρώτη ματιά στον comic χάρτη του Ηρακλείου. Περισσότερα districts
          και missions έρχονται πολύ σύντομα.
        </p>

        <div style={mapWrapper}>
          <div style={mapBackground} />
          <div style={markerWrapper}>
            <div style={markerContainer} className="lions-marker">
              <div style={markerDot} />
              <div className="lions-marker-bubble" style={bubble}>
                LIVE JAM AT LIONS SQUARE
                <span style={bubbleTail} />
              </div>
            </div>
          </div>

          <div style={bassMarkerWrapper}>
            <div
              role="button"
              tabIndex={0}
              onClick={() => setBassModalOpen(true)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault()
                  setBassModalOpen(true)
                }
              }}
              style={{ textAlign: 'center' }}
            >
              <div style={bassMarkerDot} />
              <div style={bassLabel}>The Bass Port</div>
            </div>
          </div>
        </div>
      </ComicCard>

      <ComicModal
        open={bassModalOpen}
        title="The Bass Port"
        onClose={() => setBassModalOpen(false)}
      >
        <p style={modalText}>
          Welcome to the Bass Port. Active Listeners: 1
        </p>
        <div style={modalActions}>
          <a
            href="https://musicbond.app/download"
            target="_blank"
            rel="noreferrer"
          >
            <ComicButton type="button" variant="pink">
              Dive into the 3D Experience
            </ComicButton>
          </a>
        </div>
      </ComicModal>
    </section>
  )
}

