import { ComicButton } from '../common/ComicButton'

export function Hero({ onJoinNow, onSignIn, onExploreDistricts }) {
  const layout = {
    maxWidth: 980,
    margin: '0 auto 56px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 40,
    flexWrap: 'wrap',
  }
  const heroText = { flex: '1 1 260px' }
  const kicker = {
    display: 'inline-block',
    padding: '7px 16px',
    borderRadius: 999,
    border: '3px solid #111',
    background: '#ffffff',
    boxShadow: '3px 3px 0 #111',
    fontWeight: 'bold',
    fontSize: '0.9em',
    letterSpacing: 1.5,
    marginBottom: 12,
  }
  const title = {
    fontWeight: 900,
    fontSize: '3.1em',
    letterSpacing: 2,
    color: '#ffb300',
    textTransform: 'uppercase',
    textShadow: '-4px 4px 0 #111',
    margin: 0,
  }
  const subtitle = {
    marginTop: 14,
    padding: '18px 22px',
    maxWidth: 420,
    background: '#fff',
    border: '4px solid #111',
    borderRadius: 22,
    boxShadow: '6px 6px 0 #222',
    fontWeight: 'bold',
    fontSize: '1.02em',
    lineHeight: 1.4,
  }
  const buttonsRow = {
    marginTop: 20,
    display: 'flex',
    gap: 16,
    flexWrap: 'wrap',
  }

  const heroRight = {
    flex: '0 1 260px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    minHeight: 260,
  }
  const vinylOuter = {
    width: 260,
    height: 260,
    borderRadius: '50%',
    border: '8px solid #111',
    background: 'radial-gradient(circle at 30% 30%, #444 0, #111 60%, #000 100%)',
    boxShadow: '8px 8px 0 #222',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }
  const vinylLabel = {
    width: 90,
    height: 90,
    borderRadius: '50%',
    background: '#ff1744',
    border: '6px solid #111',
    boxShadow: '0 0 0 6px #f5f5f5',
  }
  const powTag = {
    position: 'absolute',
    top: 10,
    right: -8,
    transform: 'rotate(-12deg)',
    background: '#ffeb3b',
    border: '3px solid #111',
    padding: '4px 10px',
    fontWeight: 900,
    fontSize: '0.9em',
    textTransform: 'uppercase',
    boxShadow: '3px 3px 0 #111',
  }

  return (
    <header style={layout}>
      <div style={heroText}>
        <div style={kicker}>THE COMIC MUSICVERSE</div>
        <h1 style={title}>MUSICBOND</h1>
        <p style={subtitle}>
          Εξερεύνησε μια εικονική πόλη, ανακάλυψε μουσική, στήριξε καλλιτέχνες —
          όλα μέσα σε έναν comic-style κόσμο που χτίζεται από το Music DNA σου.
        </p>
        <div style={buttonsRow}>
          <ComicButton type="button" variant="pink" onClick={onJoinNow}>
            JOIN NOW
          </ComicButton>
          <ComicButton type="button" variant="secondary" onClick={onSignIn}>
            SIGN IN
          </ComicButton>
          <ComicButton
            type="button"
            variant="yellow"
            onClick={onExploreDistricts}
            style={{ whiteSpace: 'nowrap' }}
          >
            Explore Districts
          </ComicButton>
        </div>
      </div>

      <div style={heroRight}>
        <div style={vinylOuter}>
          <div style={vinylLabel} />
        </div>
        <div style={powTag}>POW!</div>
      </div>
    </header>
  )
}

