export function FeaturesGrid({ features }) {
  const section = {
    maxWidth: 980,
    margin: '0 auto 56px',
  }
  const title = {
    textAlign: 'center',
    fontWeight: 900,
    fontSize: '2em',
    letterSpacing: 2,
    textTransform: 'uppercase',
    color: '#ffb300',
    textShadow: '-3px 3px 0 #111',
    marginBottom: 24,
  }
  const grid = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))',
    gap: 18,
  }
  const card = {
    background: '#fff',
    border: '3px solid #111',
    borderRadius: 16,
    padding: 16,
    boxShadow: '4px 4px 0 #111',
  }
  const cardTitle = {
    fontWeight: 900,
    fontSize: '1.05em',
    marginBottom: 2,
  }
  const cardSubtitle = {
    fontWeight: 'bold',
    fontSize: '0.9em',
    color: '#444',
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 1,
  }
  const cardDesc = {
    margin: 0,
    fontSize: '0.9em',
    color: '#333',
  }

  return (
    <section style={section}>
      <h2 style={title}>Features!</h2>
      <div style={grid}>
        {(features ?? []).map((f) => (
          <article key={f.title} style={card}>
            <div style={cardTitle}>{f.title}</div>
            {f.subtitle && <div style={cardSubtitle}>{f.subtitle}</div>}
            <p style={cardDesc}>{f.description}</p>
          </article>
        ))}
      </div>
    </section>
  )
}

