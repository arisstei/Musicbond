export function ComicModal({ open, title, onClose, children }) {
  if (!open) return null

  const overlay = {
    position: 'fixed',
    inset: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.35)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 40,
  }

  const modal = {
    maxWidth: 440,
    width: '90%',
    background: '#fff',
    border: '4px solid #111',
    borderRadius: 18,
    boxShadow: '8px 8px 0 #111',
    padding: 26,
    position: 'relative',
    fontFamily: 'Comic Sans MS, Comic Sans, cursive, sans-serif',
  }

  const titleStyle = {
    fontWeight: '900',
    fontSize: '1.5em',
    letterSpacing: 1,
    margin: '0 0 10px',
    color: '#222',
    textShadow: '3px 3px 0 #fbd700',
  }

  const closeBtn = {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 30,
    height: 30,
    borderRadius: '50%',
    border: '3px solid #111',
    background: '#fff',
    boxShadow: '3px 3px 0 #111',
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: '1em',
    lineHeight: '1',
  }

  return (
    <div style={overlay} onClick={onClose}>
      <div
        style={modal}
        onClick={(e) => {
          e.stopPropagation()
        }}
      >
        <button type="button" style={closeBtn} onClick={onClose}>
          ×
        </button>
        {title && <h2 style={titleStyle}>{title}</h2>}
        {children}
      </div>
    </div>
  )
}

