export function ComicButton({
  children,
  variant = 'yellow',
  style,
  ...props
}) {
  const base = {
    padding: '12px 25px',
    border: '3px solid #111',
    borderRadius: 9,
    fontWeight: 'bold',
    fontSize: '1.05em',
    boxShadow: '3px 3px 0 #111',
    cursor: props.disabled ? 'not-allowed' : 'pointer',
    transition: 'all 0.1s',
    opacity: props.disabled ? 0.75 : 1,
    userSelect: 'none',
  }

  const variants = {
    yellow: {
      background: '#fbd700',
      color: '#222',
    },
    pink: {
      background: '#ff2d55',
      color: '#fff',
    },
    secondary: {
      background: '#fff',
      color: '#111',
    },
  }

  return (
    <button
      {...props}
      style={{
        ...base,
        ...(variants[variant] ?? variants.yellow),
        ...style,
      }}
    >
      {children}
    </button>
  )
}

