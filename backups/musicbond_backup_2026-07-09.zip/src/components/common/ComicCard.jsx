export function ComicCard({ children, style, ...props }) {
  return (
    <div
      {...props}
      style={{
        background: '#fff',
        border: '4px solid #111',
        borderRadius: 17,
        boxShadow: '6px 6px 0 #222',
        padding: 32,
        ...style,
      }}
    >
      {children}
    </div>
  )
}

