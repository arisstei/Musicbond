# MusicBond

React + Vite εφαρμογή για αποθήκευση profiles με Username και Music DNA στο Supabase.

## Ρύθμιση Supabase

1. Αντιγράψε το `.env.example` σε `.env`
2. Πρόσθεσε τα Supabase credentials σου:

```
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key
```

3. Βεβαιώσου ότι ο πίνακας `profiles` έχει τις ακόλουθες στήλες:
   - `username` (text)
   - `music_dna` (text)

## Εκκίνηση

```bash
npm install
npm run dev
```

## Χρήση

Ο χρήστης εισάγει το username και το Music DNA (π.χ. Rock-Blue – συνδυασμός μουσικής και αγαπημένου χρώματος). Τα δεδομένα αποθηκεύονται στον πίνακα `profiles` του Supabase.
